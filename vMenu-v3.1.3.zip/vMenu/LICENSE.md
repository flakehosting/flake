Tom Grobbe - https://www.vespura.com/

Copyright © 2017-2019

----

You can use and edit this code to your liking. However don't ever claim it to be your own code and always provide proper credit.
I will, however, not help you if you want to modify my code.
